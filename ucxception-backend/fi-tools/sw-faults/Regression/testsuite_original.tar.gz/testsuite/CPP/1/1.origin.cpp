/**
Usa getchar
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <stack>

// 101*100+20 = 10120 ~10Kb
#define BUFFER_SIZE 10120

char buffer[BUFFER_SIZE];
char hitCount[BUFFER_SIZE];

int getX(int pos, int width)
{
	return pos%(width+1)+1;
}

int getY(int pos, int width)
{
	return pos/(width+1)+1;
}

std::stack<int> answer;
int recurse(int pos, int max, int width)
{
	// Verify if we have been here already
	if (hitCount[pos] > 0) return -1;
	++hitCount[pos];

	// Verify if we are on the last line
	if ((pos >= max - width -1) && (pos < max)) 
	{
		answer.push(pos);
		return 1;
	}

	// No need to verify if leftmost/rightmost because of /n padding

	//  /  /  |
	// |  /  /  
	if (((buffer[pos] == '/') && (buffer[pos+width] == '|')) ||
	   ((buffer[pos] == '/') && (buffer[pos+width] == '/')) ||
	   ((buffer[pos] == '|') && (buffer[pos+width] == '/'))) {
		if (recurse(pos+width, max, width) == 1) 
		{
			answer.push(pos);
			return 1;
		}
	}
	/* | \ /
	   | / \  */

	if (((buffer[pos] == '|') && (buffer[pos+width+1] == '|')) ||
	   ((buffer[pos] == '\\') && (buffer[pos+width+1] == '/')) ||
	   ((buffer[pos] == '/') && (buffer[pos+width+1] == '\\'))) {
		if (recurse(pos+width+1, max, width) == 1) 
		{
			answer.push(pos);
			return 1;
		}
	}
	/* \  \  |
	    |  \  \  */

	if (((buffer[pos] == '\\') && (buffer[pos+width+2] == '|')) ||
	   ((buffer[pos] == '\\') && (buffer[pos+width+2] == '\\')) ||
	   ((buffer[pos] == '|') && (buffer[pos+width+2] == '\\'))) {
		if (recurse(pos+width+2, max, width) == 1) 
		{
			answer.push(pos);
			return 1;
		}
	}

	// Lateral. Note: Cant go back again
	if (buffer[pos] == '\\') {
		/* \/\  */
		if ((buffer[pos+1] == '/') && (buffer[pos+2] == '\\')) {
			if (recurse(pos+2, max, width) == 1) 
			{
				answer.push(pos+1);
				answer.push(pos);
				return 1;
			}
		}
		
	}
	
	if (buffer[pos] == '/') {
		/* \/\  */
		if ((buffer[pos-1] == '\\') && (buffer[pos-2] == '/')) {
			if (recurse(pos-2, max, width) == 1) 
			{
				answer.push(pos-1);
				answer.push(pos);
				return 1;
			}
		}
		
	}

	// Dead-End
	return -1;
}

int main()
{
	int i, width, height;
	while (true)
	{	
		if (scanf("%d %d\n", &height, &width) != 2) return 0;
		
		//fflush(stdin);
		int matrixSize = (width+1)*height;		
		for (i = 0; i < matrixSize; i++)
		{	buffer[i] = getchar();
			//scanf("%c", &buffer[i]);		
		}
		memset(hitCount, 0, matrixSize);

		//Search for entrances on the first line
		bool encontrou = false;
		for (i = 0 ; i < width; i++)
		{
		
			if (converter(buffer[i]) == '!') 
			{
	
				int result = recurse(i, matrixSize, width);
				if (result == 1)
				{
					int tamanhoCaminho = answer.size();
					int l;
					for (l = 0; l < tamanhoCaminho; l++) {
						if (l != 0) printf(",");
						int posTmp = answer.top();
						printf("(%d,%d)",  getY(posTmp, width), getX(posTmp, width)); 
						//printf("%d\n", posTmp);
		answer.pop();}
					printf("\n");
					
					encontrou = true;
					break;
				}
			
			
			}	
			if (encontrou) break;
		}
		if (!encontrou) printf("No Path!\n");
	} 

	// Verifica se existem mais labirintos
	//printf("%d %d\n", matrixBegin+(width+1)*(height), fgetsRead);
	return 0;
}

