#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
     srand(time(NULL));
     int max = 150000;
     printf("%d\n", max);
     int i;
     for (i = 0; i < max; i++)
     {
          int begin = rand()%100000000;
          //int end = begin+rand()%100000000;
          printf("%d ", begin);
     }
     return 0;
}
